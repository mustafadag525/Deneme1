// veritabanına test verilerinin eklenmesi
using System.Linq;
using Microsoft.EntityFrameworkCore;
using shopapp.entity;

namespace shopapp.data.Concrete.EfCore
{
    public static class SeedDatabase
    {
        public static void Seed()
        {
            var context = new ShopContext();

            // migrationslar veritabanına aktarıldı mı
            if (context.Database.GetPendingMigrations().Count() == 0)
            {
                // veritabanındaki kategori sayısını getiricek
                if (context.Categories.Count() == 0)
                {
                    // altta oluşturmuş olduğumuz kategori listesini  gönderdik ve veritabanına ekledik
                    context.Categories.AddRange(Categories);
                }

                // altta oluşturmuş olduğumuz ürün listesini  gönderdik ve veritabanına ekledik
                if (context.Products.Count() == 0)
                {
                    context.Products.AddRange(Products);
                    context.AddRange(ProductCategories);
                }
            }
            // değişikliklikleri veritabanına aktaean komut
            context.SaveChanges();
        }

        // kategori listesini geri getiricek
        // kategori tablosuna kayıt eklerken url kısmının kontrolü yapılmalı
        private static Category[] Categories = {
            new Category(){Name="Temel Gıda",Url="temel-gıda"},
            new Category(){Name="Temizlik",Url="temizlik"},
            new Category(){Name="Atıştırmalık",Url="atıştırmalık"},
            new Category(){Name="Manav",Url="manav"},

        };

        // ürün listesini geri getiricek
        private static Product[] Products = {
            new Product(){Name="Çaykur Tiryaki ",Url="gıda-caykur-tiryaki",Price=55,ImageUrl="cay.jpg",Description="İndirimli Ürün", IsApproved=true},
            new Product(){Name="Fairy Bulaşık Deterjanı",Url="temizlik-fairy-deterjan",Price=15,ImageUrl="fairy.jpg",Description="İndirimli Ürün", IsApproved=false},
            new Product(){Name="Pantene Şampuan",Url="temizlik-pantene-sampuan",Price=28,ImageUrl="pantene.jpg",Description="İndirimli Ürün", IsApproved=true},
            new Product(){Name="Komili Yağ",Url="gıda-komili-yağ",Price=150,ImageUrl="komili.jpg",Description="İndirimli Ürün", IsApproved=false},
            new Product(){Name="Ülker Kremalı Bisküvi",Url="gıda-atıstırmalık-ülker",Price=12,ImageUrl="kremali.jpg",Description="İndirimli Ürün", IsApproved=true},
        };


        // ürün kategorilerinin yazdırılması 
        private static ProductCategory[] ProductCategories={
            new ProductCategory(){Product=Products[0],Category=Categories[0]},
            new ProductCategory(){Product=Products[1],Category=Categories[2]},
            new ProductCategory(){Product=Products[2],Category=Categories[2]},
            new ProductCategory(){Product=Products[3],Category=Categories[0]},
            new ProductCategory(){Product=Products[4],Category=Categories[0]},
            new ProductCategory(){Product=Products[4],Category=Categories[2]},
        };
    }
}